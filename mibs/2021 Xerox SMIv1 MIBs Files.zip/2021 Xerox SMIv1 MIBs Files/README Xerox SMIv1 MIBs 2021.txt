Readme
April 2020
 
The MIBs provided in this file are part of the Xerox
Common Management Interface (XCMI) October 2021.

All MIBs in this file are implemented in ASN.1 syntax (*.mib format) 
and can be run through any standard MIB compiler supported by
commercially available third party SNMP managers compatible
with SMIv1 (Structure of Management Information version 1).  


The XMCI MIBs provide the network manager access to
configure the unique parameters for Xerox printers 
beyond those supported by the IETF Standards MIBs. 

Please note that XCMI is dependent on the following IETF standard MIBs. 
Please visit the IETF (http://www.ietf.org/) draft area for the latest 
version of these mibs.

-  rfc1213.mib (IETF MIB-II)  = 
the current Internet base MIB, providing low-level
monitoring of the network device node and its network
interfaces.  MIB-II is formally part of the SNMP
network management framework; the Printer MIB and
many other MIB modules require portions of MIB-II.

-  rfc2790.mib (IETF Host Resources MIB) = 
provides a view of the device as a network host with
associated hardware and software resources.  The Printer
MIB and most XCMI MIB modules utilize Host Resources.

-  rfc2707.mib (IETF Job Monitoring MIB)
provides monitoring and management tools for printer jobs.

-  rfc3805.mib (PWG Printer MIB v2) =
This obsoletes IETF rfc1759. Provides basic printer 
device description and status monitoring.

-  rfc3806.mib (Printer Finishing MIB) =
This document defines a MIB module for the management of printer
finishing device subunits.  The finishing device subunits applicable
to this MIB are an integral part of the Printer System.  This MIB
applies only to a Finisher Device that is connected to a Printer
System.

- rfc3808.mib (IANA Charset MIB)
This IANA Charset MIB [CHARMIB] module defines the single textual
convention 'IANACharset'.


The following are the XCMI MIBs included in XCMI

-  02common.mib (XCMI Common Root MIB) =
defines the root XCMI MIB node, from which all other
XCMI-defined MIB modules branch.

-  06gentc.mib and 07gen.mib (XCMI General TC) =
provide general types and mechanisms for use by other
MIBs, such as text string localization, MIB
access-contention locking, MIB object-values
reconfiguration, and SNMP trap client registration.
 
-  10hosttc.mib and 11hostx.mib (XCMI Host Resources
Extensions TC) =
provide extensions to the IETF Host Resources MIB,
including further device information, device management,
device traffic, device power management, etc.

-  15prtxtc.mib and 16prtx.mib (XCMI Printer Extensions) =
extend the IETF Printer MIB, for configuration
and installation attributes specific to a printer.

-  21rsrctc.mib and 22rsrc.mib (XCMI Document Resources TC) =
provide for management of document content resources,
particularly fonts, also forms, logos, etc.

-  40jobtc.mib, 41jobmon.mib, 42jobmtc.mib, 43jobman.mib
(XCMI Job monitoring and management) =
provide alternate management tools for printer jobs.

-  45pwgjmx.mib (XCMI Extensions to RFC2707) =
extends the PWG Job Monitoring MIB for attributes 
specific to Xerox printers.

-  50commtc.mib and 51comms.mib (XCMI Communications
Engine TC) =
provide detailed communications protocol stack graphing
and description.

-  52conftc.mib and 53config.mib (XCMI Communications
Configuration TC) =
provide for communications configuration and installation,
including NetBIOS, OSI LAN, Internet, AppleTalk, NetWare,
NetBEUI, serial,parallel, etc.

-  58svctc.mib and 59svcmon.mib (XCMI service monitoring
MIB) =
provide monitoring for additional services available on
multifunction printers.

-  93pidtc.mib (XCMI Product Identifier Textual
Conventions MIB) =
defines product identifier OIDs and device identifier
OIDs to be used by products conforming to XCMI.  


The sequence to compile these MIBs on an SNMP manager
should be in the following order:

1.  rfc1213.mib
2.  rfc2790.mib
3.  rfc2707.mib
4.  rfc3808.mib
5.  rfc3805.mib
6.  rfc3806.mib
7.  02common.mib
8.  06gentc.mib
9.  07gen.mib
10.  10hosttc.mib
11.  11hostx.mib
12.  15prtxtc.mib
13. 16prtx.mib
14. 21rsrctc.mib
15. 22rsrc.mib
16. 40jobtc.mib
17. 41jobmon.mib
18. 42jobmtc.mib
19. 43jobman.mib
20. 45pwgjmx.mib
21. 50commtc.mib
22. 51comms.mib
23. 52conftc.mib
24. 53config.mib
25. 58svctc.mib
26. 59svcmon.mib
27. 93pidtc.mib

